import torch
from torch.utils.model_zoo import load_url
import matplotlib.pyplot as plt
from scipy.special import expit
from PIL import Image
import sys
sys.path.append('..')

from blazeface import FaceExtractor, BlazeFace, VideoReader
from architectures import fornet,weights
from isplutils import utils

from pyngrok import ngrok

# Importe as bibliotecas
from flask import Flask, request, render_template_string, send_file, render_template, redirect

from werkzeug.utils import secure_filename
from flask_ngrok import run_with_ngrok
import os

# Crie o aplicativo Flask
app = Flask(__name__)
run_with_ngrok(app)  # Inicia o ngrok quando o app é executado

# Configuração do dispositivo
device = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('cpu')
face_policy = 'scale'
face_size = 224

# Inicialize o modelo de detecção facial BlazeFace
facedet = BlazeFace().to(device)
facedet.load_weights("blazeface/blazeface.pth")
facedet.load_anchors("blazeface/anchors.npy")
face_extractor = FaceExtractor(facedet=facedet)

# Função para realizar a detecção de deep fakes em imagens
def detect_deep_fake(image_path, selected_model, selected_dataset):
    im = Image.open(image_path)
    im_faces = face_extractor.process_image(img=im)
    im_face = im_faces['faces'][0] if len(im_faces['faces']) > 0 else None

    model_url = weights.weight_url['{:s}_{:s}'.format(selected_model, selected_dataset)]
    net = getattr(fornet, selected_model)().eval().to(device)
    net.load_state_dict(load_url(model_url, map_location=device, check_hash=True))
    transf = utils.get_transformer(face_policy, face_size, net.get_normalizer(), train=False)

    if im_face is not None:
        faces_t = torch.stack([transf(image=im_face)['image']])
        
        with torch.no_grad():
            faces_pred = torch.sigmoid(net(faces_t.to(device))).cpu().numpy().flatten()
        
        avg_score = expit(faces_pred.mean())
        prediction = 'FAKE' if avg_score >= 0.7 else 'REAL'
        return prediction, avg_score
    else:
        return 'Não foi possível detectar uma face na imagem.'


# Rota principal do aplicativo
@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # Verifique se a solicitação POST possui a parte do arquivo de imagem
        if 'image' not in request.files:
            return 'Nenhuma imagem foi enviada.'

        image_file = request.files['image']

        if image_file.filename == '':
            return 'Nenhum arquivo selecionado.'

        if image_file:
            filename = secure_filename(image_file.filename)
            image_path = os.path.join("/content/", filename)
            image_file.save(image_path)

            # Realize a detecção de deep fakes
            selected_model = request.form.get('selected_model')
            selected_dataset = request.form.get('selected_dataset')
            prediction, avg_score = detect_deep_fake(image_path, selected_model, selected_dataset)

            # Retorna o resultado da predição e exibe a imagem
            return render_template('index.html', prediction=prediction, filename=filename, avg_score=avg_score)
            filename = None


    return render_template('index.html')

@app.route('/redes', methods=['GET', 'POST'])
def redes():
    if request.method == 'POST':
        # Obtenha a escolha da rede do formulário
        selected_model = request.form.get('selected_model')

        # Redirecione para a página principal com a escolha da rede como parâmetro
        return redirect(url_for('upload_file', selected_model=selected_model))

    return render_template('redes.html')

# Rota para a página de informações
@app.route('/info')
def info():
    return render_template('info.html')

# Rota para voltar para a página inicial
@app.route('/inicio')
def inicio():
    return redirect('/')

# Rota para mostrar a imagem
@app.route('/show_image/<filename>')
def show_image(filename):
    image_path = os.path.join("/content/", filename)
    
    # Verifique se o arquivo de imagem existe
    if not os.path.exists(image_path):
        return "Imagem não encontrada."
    # Abra a imagem usando a PIL
    image = Image.open(image_path)

    # Redimensione a imagem para (500, 500)
    image = image.resize((500, 500), Image.ANTIALIAS)

    # Crie um arquivo temporário para a imagem redimensionada
    temp_image_path = "/content/temp_image.jpg"
    image.save(temp_image_path, format="JPEG")
    
    return send_file(image_path, mimetype='image/jpg')  # Substitua 'image/jpeg' pelo formato correto, se necessário

# Inicie o servidor Flask
if __name__ == '__main__':
    app.run()
