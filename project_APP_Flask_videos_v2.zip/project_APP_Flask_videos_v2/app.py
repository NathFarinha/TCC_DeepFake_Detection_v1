import torch
from torch.utils.model_zoo import load_url
import matplotlib.pyplot as plt
from scipy.special import expit

import sys
sys.path.append('..')

from blazeface import FaceExtractor, BlazeFace, VideoReader
from architectures import fornet,weights
from isplutils import utils

from pyngrok import ngrok

# Importe as bibliotecas
from flask import Flask, request, render_template_string, send_file, render_template, redirect

from werkzeug.utils import secure_filename
from flask_ngrok import run_with_ngrok
import os

# Crie o aplicativo Flask
app = Flask(__name__)
run_with_ngrok(app)  # Inicia o ngrok quando o app é executado

# Configuração do dispositivo
device = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('cpu')
face_policy = 'scale'
face_size = 224
frames_per_video = 32

# Inicialize o modelo de detecção facial BlazeFace
facedet = BlazeFace().to(device)
facedet.load_weights("blazeface/blazeface.pth")
facedet.load_anchors("blazeface/anchors.npy")
videoreader = VideoReader(verbose=False)
video_read_fn = lambda x: videoreader.read_frames(x, num_frames=frames_per_video)
face_extractor = FaceExtractor(video_read_fn=video_read_fn,facedet=facedet)


# Função para realizar a detecção de deep fakes com base no modelo selecionado
def detect_deep_fake(video_path, selected_model, selected_dataset):
    # Carregue o modelo selecionado
  
    model_url = weights.weight_url['{:s}_{:s}'.format(selected_model, selected_dataset)]
    net = getattr(fornet, selected_model)().eval().to(device)
    net.load_state_dict(load_url(model_url, map_location=device, check_hash=True))
    transf = utils.get_transformer(face_policy, face_size, net.get_normalizer(), train=False)

    vid_faces = face_extractor.process_video(video_path)
    faces_t = torch.stack([transf(image=frame['faces'][0])['image'] for frame in vid_faces if len(frame['faces'])])
    with torch.no_grad():
        faces_pred = net(faces_t.to(device)).cpu().numpy().flatten()
    avg_score = expit(faces_pred.mean())
    prediction = 'FAKE' if avg_score >= 0.6 else 'REAL'

    return prediction, avg_score


# Rota principal do aplicativo
@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':

        # Verifique se a solicitação POST possui a parte do arquivo de vídeo
        if 'video' not in request.files:
            return 'Nenhum vídeo foi enviado.'

        video_file = request.files['video']

        if video_file.filename == '':
            return 'Nenhum arquivo selecionado.'

        if video_file:
            filename = secure_filename(video_file.filename)
            video_path = os.path.join("/content/", filename)
            video_file.save(video_path)

            # Realize a detecção de deep fakes
            selected_model = request.form.get('selected_model')
            selected_dataset = request.form.get('selected_dataset')
            prediction, avg_score = detect_deep_fake(video_path, selected_model, selected_dataset)

            # Retorna o resultado da predição e exibe o vídeo
            return render_template('index.html', prediction=prediction, filename=filename, avg_score=avg_score)
            filename = None
    return render_template('index.html')


@app.route('/redes', methods=['GET', 'POST'])
def redes():
    if request.method == 'POST':
        # Obtenha a escolha da rede do formulário
        selected_model = request.form.get('selected_model')

        # Redirecione para a página principal com a escolha da rede como parâmetro
        return redirect(url_for('upload_file', selected_model=selected_model))

    return render_template('redes.html')

# Rota para a página de informações
@app.route('/info')
def info():
    return render_template('info.html')

# Rota para voltar para a página inicial
@app.route('/inicio')
def inicio():
    return redirect('/')

# Rota para mostrar o vídeo
@app.route('/show_video/<filename>')
def show_video(filename):
    video_path = os.path.join("/content/", filename)
    return send_file(video_path, mimetype='video/mp4')

# Inicie o servidor Flask com ngrok
if __name__ == '__main__':
    app.run()